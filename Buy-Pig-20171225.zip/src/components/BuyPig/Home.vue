﻿<template>
  <div class="hello">
    <h1 class="text-center">{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'Hello',
  data () {
    return {
      msg: '南部買山豬'
    }
  }
}
</script>
